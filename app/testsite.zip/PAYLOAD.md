# Tunnel test payload

Unzip this in the Android app's document root and serve it. Open the handset's
relay URL in a browser; `index.html` runs the whole suite automatically.

| File | What it exercises |
| --- | --- |
| `index.html` | entry point, runs every check below |
| `app.js` | the runner: re-fetches each file and compares bytes |
| `manifest.json` | expected size + checksum for every file |
| `style.css` | plain text asset |
| `data.json` | JSON escapes, nesting, number formats |
| `unicode.html` | multi-byte UTF-8 end to end |
| `space in name.txt` | percent-escaped paths (%20) |
| `assets/logo.png` | binary body, forces the base64 path |
| `assets/favicon.ico` | binary body in a nested directory |
| `assets/nested/deep/hello.txt` | multi-segment paths |
| `large.bin` | 512 KiB binary; base64 inflates it ~33% on the wire |
| `large.txt` | 128 KiB single response |
| `404.html` | app-level not-found, distinct from the relay's |

## What the app must do

1. Serve `index.html` for a request path of `/`.
2. Map file extensions to Content-Type (the runner warns, not fails, on a miss).
3. Base64-encode binary bodies and set `"isBase64Encoded": true`.
4. Echo the request's `requestId` back unchanged on every response.
5. Return 404 with `404.html` for unknown paths.

Optional: handle `POST /echo` by returning the request body. Until then that
row shows a warning, which is expected.

## Reading the results

* **ok** — byte-identical round trip.
* **warn** — content arrived intact, but the Content-Type was not what the
  bundle expected. A MIME-table issue in the app, not a tunnel bug.
* **bad** — size or checksum mismatch. The body was altered or truncated in
  transit; check base64 handling and the frame size cap first.
