// Fetches every file listed in manifest.json back through the tunnel and
// verifies it byte for byte. Byte mismatches fail; Content-Type mismatches only
// warn, since the MIME table is the handset app's business, not the relay's.
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };

  // Relative to the document, so this works under /client-123/ or any prefix.
  function url(path) {
    return new URL(path.split("/").map(encodeURIComponent).join("/"), document.baseURI).href;
  }

  function sum32(bytes) {
    var s = 0;
    for (var i = 0; i < bytes.length; i++) s = (Math.imul(s, 31) + bytes[i]) >>> 0;
    return s >>> 0;
  }

  function human(n) {
    if (n >= 1048576) return (n / 1048576).toFixed(1) + " MiB";
    if (n >= 1024) return (n / 1024).toFixed(1) + " KiB";
    return n + " B";
  }

  function row(entry, verdict, detail, size, ms) {
    var tr = document.createElement("tr");
    var cells = [
      entry.path,
      '<span class="pill ' + verdict + '">' + verdict.toUpperCase() + "</span>",
      size == null ? "—" : human(size),
      ms == null ? "—" : Math.round(ms) + " ms",
      detail || entry.note || ""
    ];
    for (var i = 0; i < cells.length; i++) {
      var td = document.createElement("td");
      if (i === 1) td.innerHTML = cells[i]; else td.textContent = cells[i];
      tr.appendChild(td);
    }
    $("results").tBodies[0].appendChild(tr);
  }

  function checkOne(entry) {
    var started = performance.now();
    return fetch(url(entry.path), { cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.arrayBuffer().then(function (buf) {
          return { res: res, bytes: new Uint8Array(buf) };
        });
      })
      .then(function (got) {
        var ms = performance.now() - started;
        var bytes = got.bytes;
        var problems = [];
        var verdict = "ok";

        if (bytes.length !== entry.size) {
          problems.push("size " + bytes.length + " != " + entry.size);
          verdict = "bad";
        } else if (sum32(bytes) !== entry.sum >>> 0) {
          problems.push("checksum mismatch — body was altered in transit");
          verdict = "bad";
        }

        var ct = (got.res.headers.get("content-type") || "").toLowerCase();
        var want = entry.type.toLowerCase().split(";")[0].trim();
        if (verdict === "ok" && ct.indexOf(want) === -1) {
          problems.push("Content-Type " + (ct || "(none)") + ", expected " + want);
          verdict = "warn";
        }

        row(entry, verdict, problems.join("; "), bytes.length, ms);
        return { verdict: verdict, bytes: bytes.length };
      })
      .catch(function (err) {
        row(entry, "bad", String(err && err.message ? err.message : err), null,
            performance.now() - started);
        return { verdict: "bad", bytes: 0 };
      });
  }

  // large.bin is generated from a known formula, so we can prove the exact
  // bytes arrived rather than trusting the checksum alone.
  function checkPattern() {
    var entry = { path: "large.bin", note: "byte-pattern spot check" };
    var started = performance.now();
    return fetch(url("large.bin"), { cache: "no-store" })
      .then(function (r) { return r.arrayBuffer(); })
      .then(function (buf) {
        var b = new Uint8Array(buf), bad = -1;
        for (var i = 0; i < b.length; i += 997) {
          if (b[i] !== (i * 7 + 11) % 251) { bad = i; break; }
        }
        if (bad === -1 && b.length > 0 && b[b.length - 1] !== ((b.length - 1) * 7 + 11) % 251) {
          bad = b.length - 1;
        }
        row(entry, bad === -1 ? "ok" : "bad",
            bad === -1 ? "sampled every 997th byte" : "first bad byte at offset " + bad,
            b.length, performance.now() - started);
        return { verdict: bad === -1 ? "ok" : "bad", bytes: 0 };
      })
      .catch(function (err) {
        row(entry, "bad", String(err), null, null);
        return { verdict: "bad", bytes: 0 };
      });
  }

  // Optional: only meaningful once the handset app handles request bodies.
  function checkPost() {
    var entry = { path: "POST /echo", note: "optional — needs POST support in the app" };
    var payload = JSON.stringify({ hello: "tunnel", when: Date.now() });
    var started = performance.now();
    return fetch(url("echo"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: payload
    })
      .then(function (res) { return res.text().then(function (t) { return { res: res, t: t }; }); })
      .then(function (got) {
        var ok = got.res.ok && got.t.indexOf("tunnel") !== -1;
        row(entry, ok ? "ok" : "warn",
            ok ? "body echoed back intact" : "HTTP " + got.res.status + " — app did not echo the body",
            got.t.length, performance.now() - started);
        return { verdict: ok ? "ok" : "warn", bytes: 0 };
      })
      .catch(function () {
        row(entry, "warn", "no response — POST not implemented yet", null, null);
        return { verdict: "warn", bytes: 0 };
      });
  }

  function run() {
    var btn = $("rerun");
    btn.disabled = true;
    $("results").tBodies[0].innerHTML = "";
    $("status").textContent = "Loading manifest…";
    $("origin").textContent = "Served from " + location.origin + location.pathname;

    var totals = { ok: 0, warn: 0, bad: 0, bytes: 0 };

    fetch(url("manifest.json"), { cache: "no-store" })
      .then(function (r) {
        if (!r.ok) throw new Error("manifest.json: HTTP " + r.status);
        return r.json();
      })
      .then(function (manifest) {
        $("status").textContent = "Checking " + manifest.files.length + " files…";
        // Sequential on purpose: keeps the table ordered and makes the per-file
        // timings meaningful instead of measuring queue contention.
        var chain = Promise.resolve();
        manifest.files.forEach(function (entry) {
          chain = chain.then(function () {
            return checkOne(entry).then(function (r) {
              totals[r.verdict === "ok" ? "ok" : r.verdict === "warn" ? "warn" : "bad"]++;
              totals.bytes += r.bytes;
              paint(totals);
            });
          });
        });
        return chain;
      })
      .then(checkPattern).then(function (r) { totals[r.verdict === "ok" ? "ok" : "bad"]++; paint(totals); })
      .then(checkPost).then(function (r) { totals[r.verdict === "ok" ? "ok" : "warn"]++; paint(totals); })
      .then(function () {
        $("status").textContent = totals.bad === 0
          ? "All checks passed. The tunnel delivered every byte intact."
          : totals.bad + " check(s) failed — the tunnel altered or dropped data.";
        $("status").className = totals.bad === 0 ? "ok" : "bad";
        btn.disabled = false;
      })
      .catch(function (err) {
        $("status").textContent = "Could not run: " + err.message;
        $("status").className = "bad";
        btn.disabled = false;
      });
  }

  function paint(t) {
    $("stat-pass").textContent = t.ok;
    $("stat-warn").textContent = t.warn;
    $("stat-fail").textContent = t.bad;
    $("stat-bytes").textContent = human(t.bytes);
  }

  $("rerun").addEventListener("click", run);
  run();
})();
